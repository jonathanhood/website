#ifndef SCENEOBJECT_H
#define SCENEOBJECT_H

#include "Color.h"
#include "Vect3d.h"

//Abstract class to define a scene object.
class SceneObject {
	public:
		virtual double doIntersect( Vect3d pos, Vect3d dir ) = 0;
		virtual Vect3d getIntersect( Vect3d pos, Vect3d dir ) = 0;
		virtual Vect3d getNormal( Vect3d pos ) = 0;
		
		/*
		 *	Getters
		 */
		virtual double getReflect(){ return reflect; }
		virtual double getShiny(){ return shiny; }
		virtual double getSpecular(){ return specular; }
		virtual double getDiffuse(){ return diffuse; }
		virtual int getID(){ return id; }
		virtual Color getBaseColor(){ return base; }
		
		/*
		 *	Setters
		 */
		virtual void setID( int _id ){ id = _id; }
		virtual void setShiny( double _shiny ){ shiny = _shiny; }
		virtual void setDiffuse( double _diffuse ){ diffuse = _diffuse; }
		virtual void setSpecular( double _specular ){ specular = _specular; }
		virtual void setReflect( double _reflect ){ reflect = _reflect; }
		virtual void setBaseColor( Color _base ){ base = _base; }
	
	protected:
		Color base;
		double shiny;
		double diffuse;
		double specular;
		double reflect;
		int id;
};

#endif


