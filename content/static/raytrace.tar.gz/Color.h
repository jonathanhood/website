#ifndef COLOR_H
#define COLOR_H

class Color {
public:
	double r;
	double g;
	double b;
	
	Color() {
		r = g = b = 0;
	}
	
	Color( double _r, double _g, double _b ) {
		r = _r;
		g = _g;
		b = _b;
	}
	
	void limit( double l ) {
		if( r > l ) r = l;
		if( g > l ) g = l;
		if( b > l ) b = l;
	}
	
	/*
	 *	Operator overload
	 */
	 Color & operator=(const Color right) {
		r = right.r;
		g = right.g;
		b = right.b;
	 }
	 
	 Color operator-(const Color right ) {
		Color result( r - right.r, g - right.g, b - right.b );
		return result;
	 }
	 
	 Color operator+(const Color right ) {
		Color result( r + right.r, g + right.g, b + right.b );
		return result;
	 }
	 
	 Color operator*(const double right ) {
		return Color( r*right, g*right, b*right );
	 }
};

#endif

