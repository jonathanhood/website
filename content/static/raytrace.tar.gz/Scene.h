#ifndef SCENE_H
#define SCENE_H

#include <vector>
#include "Vect3d.h"
#include "SceneObject.h"

using namespace std;

class Scene {
public:
	static Scene* getInstance() {
		static Scene* inst = 0;
		if( inst == 0 ) {
			inst = new Scene();
		}
		
		return inst;
	}
	
	SceneObject* doIntersect( Vect3d pos, Vect3d dir , SceneObject* obj = NULL) {
		double min = -1;
		SceneObject* closest = NULL;
		for(int i = 0; i < objects.size(); i++ ) {
			SceneObject* object = objects[i];
			double dist = object->doIntersect( pos, dir );
			
			if( (dist < min || min == -1) && dist > 0) {
				if( obj != NULL && obj->getID() != object->getID() ) {
					min = dist;
					closest = object;
				} else if( obj == NULL ) {
					min = dist;
					closest = object;
				}
			}
		}
		
		return closest;
	}
	
	vector<Vect3d> getLights() {
		return lights;
	}
	
	void addLight( Vect3d light ) {
		lights.push_back( light );
	}
	
	void addObject( SceneObject* obj ) {
		static int id = 0;
		obj->setID( id );
		id++;
		objects.push_back( obj );
	}
	
	void setCamera( Vect3d _cam ) {
		cam = _cam;
	}
	
	Vect3d getCamera() {
		return cam;
	}

private:
	Scene(){ 
		cam = Vect3d( 0, 0, -10 );
	}
	
	vector<SceneObject*> objects;
	vector<Vect3d> lights;
	Vect3d cam;
};

#endif

