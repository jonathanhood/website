#ifndef SPHERE_H
#define SPHERE_H

#include "Vect3d.h"
#include "Ray.h"

//Abstract class to define a scene object.
class Sphere : public SceneObject {
public:
	Sphere() {
		center.x = center.y = center.z = 0;
		r = 1;
		shiny = 128;
		diffuse = 0;
		specular = .2;
		reflect = .8;
		base = Color( 1, 1, 0 );
	}
	
	Sphere( Vect3d c, double _r ) {
		center = c;
		r = _r;
		shiny = 128;
		diffuse = 0;
		specular = .2;
		reflect = .8;
		base = Color( 1, 1, 0 );
	}

	virtual double doIntersect( Vect3d pos, Vect3d dir ) {
		//Solve for intersection distance using the quadratic equation
		double a = dir.dot( dir );
		double b = (pos - center).dot( dir )*2;
		double c = (pos-center).dot(pos-center) - r*r;

		//Use the discriminant to determine if this equation has any solutions
		double disc = b*b -4*a*c;
		if( disc < 0 ) return -1;
		else if( disc == 0 ) {
			//One solution
			double solution = -1*b/(2*a);
			if( solution > 0 )
				return solution;
			else return -1;
		} else {
			//Two solutions, find nearest
			double solution1 = ( -1*b + sqrt( disc ))/(2*a);
			double solution2 = ( -1*b - sqrt( disc ))/(2*a);
			
			double final;
			if( solution1 < solution2 ) final = solution1;
			else final = solution2;

			if( final > 0 )
				return final;
			else return -1;
		}
	}
	
	virtual Vect3d getIntersect( Vect3d pos, Vect3d dir ){
		double dist = doIntersect( pos, dir );
		
		return pos + dir*dist;
	}
	
	virtual Vect3d getNormal( Vect3d pos ){
		Vect3d norm = pos - center;
		norm.normalize();
		return norm;
	}
	
private:
	Vect3d center;
	double r;
};

#endif