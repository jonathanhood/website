#ifndef VECT_H
#define VECT_H

#include <vector>
#include <math.h>

using namespace std;

class Matrix4x4;

class Vect3d {
public:
	Vect3d();
	
	Vect3d( double x, double y, double z );
	
	void normalize();
	
	double dot( const Vect3d other );
	
	Vect3d cross( const Vect3d other );
	
	//Vect3d toObject( Vect3d origin, Vect3d xaxis, Vect3d yaxis, Vect3d zaxis );
	
	//Vect3d toGlobal( Vect3d origin, Vect3d xaxis, Vect3d yaxis, Vect3d zaxis );
	
	const double magnitude() ;
	
	/*
	 *	Operator overload
	 */
	 Vect3d & operator=(const Vect3d right);
	 
	 Vect3d operator-(const Vect3d right );
	 
	 Vect3d operator+(const Vect3d right );
	 
	 Vect3d operator*(const double right );
	 
	double x;
	double y;
	double z;
};

class Matrix4x4 {
public:
	Matrix4x4();
	
	//Multiply this matrix by a vector
	Vect3d operator*( const Vect3d right );
	
	vector<double> row1;
	vector<double> row2;
	vector<double> row3;
	vector<double> row4;
};

#include "Vect3d.h"
#include <vector>
#include <math.h>

using namespace std;

Vect3d::Vect3d() {
	x = y = z = 0;
}
	
Vect3d::Vect3d( double x, double y, double z ) {
		this->x = x;
		this->y = y;
		this->z = z;
}
	
void Vect3d::normalize() {
	double mag = this->magnitude();
	x /= mag;
	y /= mag;
	z /= mag;
}
	
double Vect3d::dot( const Vect3d other ) {
	return x*other.x + y*other.y + z*other.z;
}
	
Vect3d Vect3d::cross( const Vect3d other ) {
	Vect3d thecross( y*other.z - z*other.y, z*other.x - x*other.z, x*other.y - y*other.x );
	
	return thecross;
}
	
/*
Vect3d Vect3d::toGlobal( Vect3d origin, Vect3d xaxis, Vect3d yaxis, Vect3d zaxis ) {
	//FIXME: This is wrong.
	Matrix4x4 inner;
	inner.row1[0] = xaxis.x; inner.row1[1] = yaxis.x; inner.row1[2] = zaxis.x;
	inner.row2[0] = xaxis.y; inner.row2[1] = yaxis.y; inner.row2[2] = zaxis.y;
	inner.row3[0] = xaxis.z; inner.row3[1] = yaxis.z; inner.row3[2] = zaxis.z;
	inner.row4[3] = 1;
	
	Matrix4x4 outer;
	inner.row1[0] = 1; inner.row1[3] = origin.x;
	inner.row2[1] = 1; inner.row2[3] = origin.y;
	inner.row3[2] = 1; inner.row3[3] = origin.z;
	inner.row4[3] = 1;
	
	Vect3d result1 = inner * *this;
	Vect3d result2 = outer * result1;
	
	return result2;
}

Vect3d Vect3d::toObject( Vect3d origin, Vect3d xaxis, Vect3d yaxis, Vect3d zaxis ) {
	Matrix4x4 inner;
	inner.row1[0] = 1; inner.row1[3] = origin.x;
	inner.row2[1] = 1; inner.row2[3] = origin.y;
	inner.row3[2] = 1; inner.row3[3] = origin.z;
	inner.row4[3] = 1;
	
	Matrix4x4 outer;
	outer.row1[0] = xaxis.x; outer.row1[1] = xaxis.y; outer.row1[2] = xaxis.z;
	outer.row2[0] = yaxis.x; outer.row2[1] = yaxis.y; outer.row2[2] = yaxis.z;
	outer.row3[0] = zaxis.x; outer.row3[1] = zaxis.y; outer.row3[2] = zaxis.z;
	outer.row4[3] = 1;
	
	//cout << "To Object Space" << endl;
	//cout << "\tInput: " << x << "," << y << "," << z << endl;
	Vect3d result1 = inner * *this;
	//cout << "\tStage1: " << result1.x << "," << result1.y << "," << result1.z << endl;
	Vect3d result2 = outer * result1;
	//cout << "\tFinal: " << result2.x << "," << result2.y << "," << result2.z << endl;
	
	return result2;
}*/
	
const double Vect3d::magnitude() {
	return sqrt( x*x + y*y +z*z );
}
	
/*
 *	Operator overload
 */
Vect3d & Vect3d::operator=(const Vect3d right) {
	x = right.x;
	y = right.y;
	z = right.z;
}
	 
Vect3d Vect3d::operator-(const Vect3d right ) {
	Vect3d result( x - right.x, y - right.y, z - right.z );
	return result;
}
	 
Vect3d Vect3d::operator+(const Vect3d right ) {
	Vect3d result( x + right.x, y + right.y, z + right.z );
	return result;
}
	 
Vect3d Vect3d::operator*(const double right ) {
	return Vect3d( x*right, y*right, z*right );
}


Matrix4x4::Matrix4x4() {
	for(int i = 0; i < 4; i ++ ) {
		row1.push_back(0);
		row2.push_back(0);
		row3.push_back(0);
		row4.push_back(0);
	}
}
	
//Multiply this matrix by a vector
Vect3d Matrix4x4::operator*( const Vect3d right ) {
	Vect3d result;
	result.x = row1[0] * right.x + row1[1] * right.y + row1[2] * right.z + row1[3] * 1;
	result.y = row2[0] * right.x + row2[1] * right.y + row2[2] * right.z + row2[3] * 1;
	result.z = row3[0] * right.x + row3[1] * right.y + row3[2] * right.z + row3[3] * 1;
	
	return result;
}


#endif
