/******************************************************************************
*Jonathan Hood
*Raytracer for Intro. to Computer Graphics (CSE 4413)
*
*This program implements a simple raytracer.  It supports tracing planes, boxes,
*Cylinders,  and Spheres.  It can simulate reflection and the effects of multiple
*point light sources.  Finally, it supports supersampling for 1, 4, 9, and 16 
*samples per pixel.
*
*This program uses:
*	freeglut3 http://freeglut.sourceforge.net/
******************************************************************************/

//Include Glut
#ifdef __APPLE__
#	include <GLUT/glut.h>
#else
#	include <GL/glut.h>
#endif

#include "Ray.h"
#include "Sphere.h"
#include "Plane.h"
#include "Cylinder.h"
#include "Box.h"
//#include "Cone.h" (Incomplete Code)
#include <iostream>
#include <string>
#include <time.h>
//#include <sstream>

using namespace std;

//Define screen width and height at start.
int w = 500;
int h = 500;

//Define number of samples per pixel. Should be 1, 4, 9, or 16
int numsamples = 1;

//Perform a render on the scene using the ray tracing method.
void doRender() {
	cout << "Starting Render... ";
	flush( cout );
	double start = clock();

	//Pixel buffer, acts as an accumulation buffer when supersampling
	float* rgb_buf = new float[w * h * 3]; 

	double horiz_size = (float)w/(float)h;
	
	//Calculate distance between each sample.
	double horiz_stepsize = ( horiz_size / (w * sqrt(numsamples) ));
	double vert_stepsize = ( 1 / (h * sqrt(numsamples) ));

	double horiz_start = -1.f * horiz_size / 2.f;
	
	//Initialize buffer to black
	for( int i = 0; i < w*h*3; i++ ) {
		rgb_buf[i] = 0;
	}
	
	//Move through the scene.  Start at the top left, then move right.  Finish a line,
	//then move to the next.
	for( int r = 0; r < h*sqrt(numsamples); r++ ) {
		for( int c = 0; c < w*sqrt(numsamples); c++ ) {;
			//Calculate ray
			Ray theRay;
			theRay.pos = Vect3d( 0, 0, -10 );
			theRay.dir = Vect3d( horiz_start + horiz_stepsize*c, -.5 + vert_stepsize*r, 1);
		
			//Shoot the ray
			Color pixel = theRay.shoot();
		
			//Write pixel to buffer
			int y = r / sqrt(numsamples);
			int x = c / sqrt(numsamples);
			int bufpos = (y*w + x);
			bufpos = bufpos * 3;
			rgb_buf[bufpos] += pixel.r;
			rgb_buf[bufpos + 1] += pixel.g;
			rgb_buf[bufpos + 2] += pixel.b;
		
		}
	}
	
	//Normalize buffer by number of samples.
	for(int i = 0; i < w*h*3; i++) rgb_buf[i] /= numsamples;
	
	//Write buffer to screen
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glDrawPixels( w, h, GL_RGB, GL_FLOAT, (void*)rgb_buf );
	glutSwapBuffers();
	delete [] rgb_buf;
	
	//Display render time
	double end = clock();
	cout << "[DONE]" << endl;
	cout << "Render Time: " << (end - start)/CLOCKS_PER_SEC << " sec" << endl;
	
	return;
}

// ResizeWindow is called when the window is resized.  Taken and adapted from Solar.c
static void resizeWindow(int _w, int _h)
{
	h = _h;
	w = _w;
    float aspectRatio;
	h = (h == 0) ? 1 : h;
	w = (w == 0) ? 1 : w;
	glViewport( 0, 0, w, h );	// View port uses whole window
	aspectRatio = (float)w/(float)h;
	
	//tracer.setSampleSize( h, w );

	// Set up the projection view matrix (not very well!)
    glMatrixMode( GL_PROJECTION );
    glLoadIdentity();
    gluPerspective( 60.0, aspectRatio, 1.0, 30.0 );

	// Select the Modelview matrix
    glMatrixMode( GL_MODELVIEW );
}

int main( int argc, char** argv ) {
	Scene* scene = Scene::getInstance();
	
	//Add some spheres to the scene
	scene->addObject( new Sphere( Vect3d( -3, -4, 4 ), 1 ) );
	scene->addObject( new Sphere( Vect3d( -2, -4, 6 ), 1 ) );
	scene->addObject( new Sphere( Vect3d( -1, -4, 4 ), 1 ) );
	scene->addObject( new Sphere( Vect3d( 0, -4, 6 ), 1 ) );
	scene->addObject( new Sphere( Vect3d( 5, 5, 10), 4 ) );
	
	//Add some planes to create a room for our scene
	scene->addObject( new Plane( Vect3d( 0, -5, 0 ), Vect3d( 0, 1, 0 ), Color( .8, .2, .4 ) ) );
	scene->addObject( new Plane( Vect3d( -5, 0, 0 ), Vect3d( 1, 0, 0 ), Color( .7, .8, .2 ) ) );
	scene->addObject( new Plane( Vect3d( 0, 0, 10 ), Vect3d( 0, 0, -1) , Color( .2, .6, .8) ) );
	scene->addObject( new Plane( Vect3d( 5, 0, 0 ), Vect3d(-1, 0, 0 ), Color( .4, .2, 1 ) ) );
	scene->addObject( new Plane( Vect3d( 0, 5, 0 ), Vect3d( 0, -1, 0 ), Color( 1, 1, 1 ) ) );
	scene->addObject( new Plane( Vect3d( 0, 0, -10 ), Vect3d( 0, 0, 1) ) );
	
	//Add Cylinders
	//scene->addObject( new Cylinder( Vect3d( 3, -5, 4 ),  1, 1) );
	Cylinder* column = new Cylinder( Vect3d( -5, -5, 10), 10, 2 );
	column->setReflect( .8 );
	column->setDiffuse( 0 );
	column->setSpecular( .2 );
	column->setBaseColor( Color( 1, 1, 1 ) );
	column->setShiny( 128 );
	scene->addObject( column );
	
	//Add Cone
	scene->addObject( new Cylinder( Vect3d( 3, -5, 4 ), 1, 1 ) );
	
	//Add Boxes
	scene->addObject( new Box( Vect3d( 4.5, -3, 9.5 ), 4, 1, 1) );
	
	//Add Lights
	scene->addLight( Vect3d( 0, 4.5, 2 ) );
	scene->addLight( Vect3d( 0, 4.5, -2 ) );
	scene->addLight( Vect3d( 4.5, 0, -9.5) );
	
	/*scene->addLight( Vect3d(0, 4.5, 2.4 ));
	scene->addLight( Vect3d(0, 4.5, 1.6 ));
	scene->addLight( Vect3d(-.4, 4.5, 2 ) );
	scene->addLight( Vect3d(.4, 4.5, 2 ) );
	scene->addLight( Vect3d(.4, 4.5, 2.4) );
	scene->addLight( Vect3d(.4, 4.5, 1.6) );
	scene->addLight( Vect3d(-.4, 4.5, 2.4) );
	scene->addLight( Vect3d(-.4, 4.5, 1.6) );*/

	//Init glut and create a window
	glutInit( &argc, argv );
	glutInitDisplayMode( GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH );
	//glutInitWindowPosition( 0, 0 );
	glutInitWindowSize( w, h  );
	glutCreateWindow( "Raytrace" );

	//Init OpenGL
	glShadeModel( GL_FLAT );
	glClearColor( 0.0, 0.0, 0.0, 0.0 );
	glClearDepth( 1.0 );
	glEnable( GL_DEPTH_TEST );

	//Register glut callbacks
	glutReshapeFunc( resizeWindow );
	glutDisplayFunc( doRender );

	//Go!
	//Note: This blocks until window is closed.
	glutMainLoop();
	
	return 0;
}	
