#ifndef CONE_H
#define CONE_H

#include "Vect3d.h"
#include "Ray.h"
#include "Plane.h"

class Cone : public SceneObject {
public:
	Cone() {
		center = Vect3d(0, 0, 0);
		r = 1;
		h = 1;
		shiny = 20;
		diffuse = .5;
		specular = .5;
		reflect = 0;
		base = Color( 1, 1, 0 );
	}
	
	Cone( Vect3d p, double height, double radius ) {
		center = p;
		h = height;
		r = radius;

		shiny = 20;
		diffuse = .5;
		specular = .5;
		reflect = 0;
		base = Color( 1, 1, 0 );
	}
	
	virtual double doIntersect( Vect3d pos, Vect3d dir ) {
		//Make cylinder the origin
		pos = pos - center;
		double radius = h - (pos.y*r)/h;
		
		if( radius < 0 ) radius = 0;
	
		//First, check for an intersection with the cylinder itself
		double a = dir.x*dir.x + dir.z*dir.z;
		double b = 2*( dir.x*pos.x + dir.z*pos.z);
		double c = pos.x*pos.x + pos.z*pos.z - radius*radius;
		
		double disc = b*b - 4 * a * c;
		
		double dist = -1;
		if( disc == 0 ) {
			//One result
			dist = -1*b/(2*a);
		} else if( disc > 0 ) {
			//Two result, choose smallest dist
			double result1 = ( -1*b + sqrt( disc ) )/(2*a);
			double result2 = ( -1*b - sqrt( disc ) )/(2*a);
			
			if( result1 < result2 ) dist = result1;
			else dist = result2;
		}
		
		
		//Clamp values to limit cylinder height
		Vect3d intersect = getIntersect( pos, dir, dist );
		if( !(intersect.y >= 0 && intersect.y <= h) ) dist = -1;
		
		//Now, check for an intersection with the caps using planes.
		wasPlane = false;
		Plane top( Vect3d( 0, h, 0 ), Vect3d( 0, 1, 0 ) );
		Plane bottom( Vect3d( 0, .0001, 0 ), Vect3d( 0, -1, 0 ) );
		double topDist = top.doIntersect( pos, dir );
		double bottomDist = bottom.doIntersect( pos, dir );
		
		//Check the top cap.
		/*if( topDist <= dist || dist == -1 ) {
			dist = -1;
			Vect3d topInt = top.getIntersect( pos, dir );
			double r_top = sqrt(topInt.x*topInt.x + topInt.z*topInt.z);
			if( r_top <= r ){
				wasPlane = true;
				dist = topDist;
			}
		}*/
		
		//Check the bottom cap
		if( bottomDist <= dist || dist == -1) {
			Vect3d bottomInt = bottom.getIntersect( pos, dir );
			double r_bottom = sqrt(bottomInt.x*bottomInt.x + bottomInt.z*bottomInt.z);
			
			if( r_bottom <= r ){
				wasPlane = true;
				dist = bottomDist;
			}
		}
		
		//Return smallest distance found, or -1 on no intersection
		if( dist > 0 ){
			//cout << "Radius: " << radius << endl;
			return dist;
		} else return -1;
	}
	
	virtual Vect3d getIntersect( Vect3d pos, Vect3d dir ) {
		double dist = doIntersect( pos, dir );
		Vect3d result = pos + dir*dist;
		
		return result;
	}
	
	virtual Vect3d getNormal( Vect3d pos ) {
		pos = pos - center;
		
		//double radius = (1/h)*pos.y*r;
		
		//See if this point lies on the cylinder or on the caps.  If so, give
		//the normal for the plane.
		if( wasPlane ) {
			if( pos.y < h/2 ) return Vect3d( 0, -1, 0 );
			//if( pos.y > h/2) return Vect3d( 0, 1, 0);
		}
	
		//Point lies on cylinder
		Vect3d foo( 0, pos.y, 0 );
		Vect3d norm = pos - foo;
		norm.normalize();
		//norm.y += radius;
		//norm.normalize();
		
		return norm;
	}
	
private:
	Vect3d getIntersect( Vect3d pos, Vect3d dir, double dist ) {
		return pos + dir*dist;
	}
	
	Vect3d center;

	bool wasPlane;
	double r;
	double h;
};

#endif 
