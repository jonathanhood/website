#ifndef RAY_H
#define RAY_H

#include <vector>
#include <iostream>
#include "Color.h"
#include "Vect3d.h"
#include "Scene.h"
#include "SceneObject.h"

using namespace std;

//Set the maximum number of recursions when simulating  reflection
//Set to 0 for no reflections
#define MAX_DEPTH 16

class Ray {
public:
	//Store starting point and direction vector
	Vect3d pos;
	Vect3d dir;

	//Shoot this ray into the scene
	Color shoot( int depth = 0 ) {
		//Find the nearest object
		Scene* scene = Scene::getInstance();
		SceneObject* nearest = scene->doIntersect( pos, dir );
		
		//Set default  color to black
		Color result;
		result.r = result.g = result.b = 0;

		//Search for the nearest intersectin
		if( nearest != NULL ) {
			//Object found, get required values
			Vect3d intersect = nearest->getIntersect( pos, dir );
			Vect3d normal = nearest->getNormal( intersect );
			result = nearest->getBaseColor();
			
			//Do reflection, if required
			Color reflected;
			double reflect = nearest->getReflect();
			if( reflect > 0 && depth < MAX_DEPTH ) {
				Ray reflect;
				reflect.pos = intersect;
				reflect.dir = dir - normal*(dir.dot(normal))*2;
				reflect.dir.normalize();
				reflected = reflect.shoot( depth + 1 );
			} else {
				reflected.r = reflected.g = reflected.b = 0;
			}
			
			
			//Calculate shading values againt all light sources.
			double diffuse 	= 0;
			double specular = 0;
			double light 	= 0;
			double shiny 	= nearest->getShiny();
			vector<Vect3d> lights = scene->getLights();
			for( int i = 0; i < lights.size(); i++ ) {
				//First, calculate all the required vectors
				Vect3d lightPos = lights[i];
				Vect3d lightDir = lightPos - intersect;
				lightDir.normalize();
				Vect3d camDir = intersect - scene->getCamera();
				camDir.normalize();
				Vect3d reflectDir = lightDir - normal*(lightDir.dot( normal ))*2;
				reflectDir.normalize();
				
				//Do diffuse lighting
				diffuse += lightDir.dot( normal );
				
				//Do specular
				double dot = reflectDir.dot( camDir );
				if( dot > 0 ) {
					specular += pow( dot, shiny );
				}
				
				//Do shadow
				if( !testShadowRay( intersect, lightDir, lightPos, nearest ) ) {
					light += 1;
				} 
			}
			
			//Normalize by number of light sources
			diffuse /= lights.size();
			specular /= lights.size();
			light /= lights.size();
			
			//Correct based on surface properties
			diffuse = nearest->getDiffuse() * diffuse;
			specular = nearest->getSpecular() * specular;
			
			//Calculate result color.
			result = (result*diffuse + result*specular)*light + reflected*reflect;
			result.limit( 1 );
		}
		
		return result;
	}
	
	//Returns true if there is an intersection between pos and light along dir.
	bool testShadowRay( Vect3d pos, Vect3d dir, Vect3d light, SceneObject* obj) {
		Scene* scene = Scene::getInstance();
		SceneObject* nearest = scene->doIntersect( pos, dir, obj );
		if( nearest == NULL ) {
			return false;
		}
		
		double dist = nearest->doIntersect( pos, dir );
		double max = (pos - light).magnitude();
		
		if( dist > 0 && dist < max ) return true;
		else return false;  
	}
};

#endif
