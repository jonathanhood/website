raytrace by Jonathan Hood (jhh205@msstate.edu)

This program implements a simple raytracer.  It supports tracing planes, boxes,
Cylinders,  and Spheres.  It can simulate reflection and the effects of multiple
point light sources.  Finally, it supports supersampling for 1, 4, 9, and 16 
samples per pixel.

This program is known working on ubuntu 9.10 and Mac OSX.  It should only require the glut library.

To compile this program

Linux:
g++ -o raytrace -l glut main.cpp

Mac OSX:
g++ -o raytrace -framework OpenGL -framework Glut main.cpp

NOTES:
The attached picture was taken with 9x supersampling enabled, but the current version in this archive 
has supersampling disabled.  If you wish to re-enable ss, simple change numsamples in main.cpp.  It
should be noted that this program is significanlty slower with ss enabled.
