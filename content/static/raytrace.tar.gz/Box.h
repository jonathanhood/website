#ifndef BOX_H
#define BOX_H

#include "Ray.h"

class Box : public SceneObject {
public:
	Box() {
		h = 2;
		w = 1;
		d = 1;
		center = Vect3d( 0, 0, 0 );
		
		reflect = 0;
		diffuse = .8;
		shiny = 20;
		specular = .2;
		base = Color( .6, .3, .9 );
	}
	
	Box( Vect3d c, double _h, double _w, double _d ) {
		center = c;
		
		h = _h;
		w = _w;
		d = _d;
		
		reflect = 0;
		diffuse = .8;
		shiny = 20;
		specular = .2;
		base = Color( .6, .3, .9 );
	}

	virtual double doIntersect( Vect3d pos, Vect3d dir ) {
		//Make center the origin
		pos = pos - center;
		
		//Build the Planes
		Plane top( Vect3d(0, h/2, 0), Vect3d(0, 1, 0 ) );
		Plane bottom( Vect3d( 0, -1*h/2, 0 ), Vect3d( 0, -1, 0 ) );
		Plane right( Vect3d( w/2, 0, 0 ), Vect3d( 1, 0, 0 ) );
		Plane left( Vect3d( -1*w/2, 0, 0 ), Vect3d( -1, 0, 0 ) );
		Plane back( Vect3d( 0, 0, d/2 ), Vect3d( 0, 0, 1 ) );
		Plane front( Vect3d( 0, 0, -1*d/2 ), Vect3d( 0, 0, -1 ) );
		
		double dist = -1;
		
		//Check top
		double temp_dist = top.doIntersect( pos, dir );
		if( temp_dist > 0 && (temp_dist < dist || dist == -1 ) ) {
			Vect3d temp_int = top.getIntersect( pos, dir );
			bool onBox = temp_int.x >= -1*w/2 && temp_int.x <= w/2 && temp_int.z >= -1*d/2 && temp_int.z <= d/2;
			if( onBox ) dist = temp_dist; 
		}
		
		//Check bottom
		temp_dist = bottom.doIntersect( pos, dir );
		if( temp_dist > 0 && (temp_dist < dist || dist == -1 ) ) {
			Vect3d temp_int = bottom.getIntersect( pos, dir );
			bool onBox = temp_int.x >= -1*w/2 && temp_int.x <= w/2 && temp_int.z >= -1*d/2 && temp_int.z <= d/2;
			if( onBox ) dist = temp_dist; 
		}
		
		//Check right
		temp_dist = right.doIntersect( pos, dir );
		if( temp_dist > 0 && (temp_dist < dist || dist == -1 ) ) {
			Vect3d temp_int = right.getIntersect( pos, dir );
			bool onBox = temp_int.y >= -1*h/2 && temp_int.y <= h/2 && temp_int.z >= -1*d/2 && temp_int.z <= d/2;
			if( onBox ) dist = temp_dist; 
		}
		
		//Check left
		temp_dist = left.doIntersect( pos, dir );
		if( temp_dist > 0 && (temp_dist < dist || dist == -1 ) ) {
			Vect3d temp_int = left.getIntersect( pos, dir );
			bool onBox = temp_int.y >= -1*h/2 && temp_int.y <= h/2 && temp_int.z >= -1*d/2 && temp_int.z <= d/2;
			if( onBox ) dist = temp_dist; 
		}
		
		//Check back
		temp_dist = back.doIntersect( pos, dir );
		if( temp_dist > 0 && (temp_dist < dist || dist == -1 ) ) {
			Vect3d temp_int = back.getIntersect( pos, dir );
			bool onBox = temp_int.y >= -1*h/2 && temp_int.y <= h/2 && temp_int.x >= -1*w/2 && temp_int.x <= w/2;
			if( onBox ) dist = temp_dist; 
		}
		
		//Check front
		temp_dist = front.doIntersect( pos, dir );
		if( temp_dist > 0 && (temp_dist < dist || dist == -1 ) ) {
			Vect3d temp_int = front.getIntersect( pos, dir );
			bool onBox = temp_int.y >= -1*h/2 && temp_int.y <= h/2 && temp_int.x >= -1*w/2 && temp_int.x <= w/2;
			if( onBox ) dist = temp_dist; 
		}
		
		return dist;
	}
	
	virtual Vect3d getIntersect( Vect3d pos, Vect3d dir ) { 
		double dist = doIntersect( pos, dir );
		Vect3d result = pos + dir*dist;
		
		return result;
	}
	
	virtual Vect3d getNormal( Vect3d pos ) {
		//Make center the origin
		pos = pos - center;
		
		//Build the Planes
		Plane top( Vect3d(0, h/2, 0), Vect3d(0, 1, 0 ) );
		Plane bottom( Vect3d( 0, -1*h/2, 0 ), Vect3d( 0, -1, 0 ) );
		Plane right( Vect3d( w/2, 0, 0 ), Vect3d( 1, 0, 0 ) );
		Plane left( Vect3d( -1*w/2, 0, 0 ), Vect3d( -1, 0, 0 ) );
		Plane back( Vect3d( 0, 0, d/2 ), Vect3d( 0, 0, 1 ) );
		Plane front( Vect3d( 0, 0, -1*d/2 ), Vect3d( 0, 0, -1 ) );
		
		//Get percent closeness to w/h/d
		double xdif = (w/2 - pos.x) / (w/2);
		if( pos.x < 0 ) xdif = (w/2 + pos.x ) / (w/2);
		
		double ydif = (h/2 - pos.y) / (h/2);
		if( pos.y < 0 ) ydif = (pos.y + h/2) / (h/2);
		
		double zdif = (d/2 - pos.z) / (d/2);
		if( pos.z < 0 ) zdif = (pos.z + d/2) / (d/2);
		
		//Find the type of face I'm closest to, then decide which plane normal to return
		if( xdif < ydif && xdif < zdif ) {
			//On an x-face
			if( pos.x < 0 ) return left.getNormal(pos);
			return right.getNormal(pos);
		} else if(ydif < xdif && ydif < zdif ) {
			//On a y-face
			if( pos.y < 0 ) return bottom.getNormal(pos);
			return top.getNormal(pos);
		} else if( zdif < xdif && zdif < ydif ) {
			//On a z-face
			if( pos.z < 0 ) return front.getNormal(pos);
			return back.getNormal(pos);
		}
	}
		
private:
	double h;
	double w;
	double d;
	Vect3d center;
};

#endif