#ifndef PLANE_H
#define PLANE_H

#include "Vect3d.h"
#include "Ray.h"

class Plane : public SceneObject {
public:
	Plane() {
		point = Vect3d( 0, -1, 0 );
		normal = Vect3d( 0, 1, 0 );
		base = Color(1, 0, 1);
		
		shiny = 20;
		diffuse = .8;
		specular = .2;
		reflect = 0;
		base = Color( 1, 1, 0 );
	}
	
	Plane( Vect3d p, Vect3d n ) {
		point = p;
		normal = n;
		base = Color(1, 0, 1);
		
		shiny = 10;
		diffuse = .8;
		specular = .2;
		reflect = 0;
		base = Color( 1, 1, 0 );
	}
	
	Plane( Vect3d p, Vect3d n, Color c ) {
		point = p;
		normal = n;
		base = c;
		
		shiny = 10;
		diffuse = .8;
		specular = .2;
		reflect = 0;
	}

	virtual double doIntersect( Vect3d pos, Vect3d dir ) {
		double result = (point - pos).dot(normal) / ( dir.dot( normal ) );
		
		if( result <= 0 ) return -1;
		else {
			//cout << "Plane Intersect Dist: " << result << endl;
			return result;
		}
	}
	
	virtual Vect3d getIntersect( Vect3d pos, Vect3d dir ) {
		double dist = doIntersect( pos, dir );
		
		return pos + dir*dist;
	}
	
	virtual Vect3d getNormal( Vect3d pos ) {
		return normal;
	}
	
private:
	Vect3d point;
	Vect3d normal;
};

#endif
